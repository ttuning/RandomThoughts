---
category: openSourceConfiguration
tocprty: 1
---

# Configure Python for SAS Viya

## Overview

NOTE: The ZIP file stored in this folder is meant to be used to reinstall Python on its persistent volume if the Viya namespace is deleted for any reason. That is because Python is notinstalled on the OS and nfs-mounted on the cluster. The persistent volume is shared by the sas-cas-server-default-controller and the sas-microanalytic pods.

To install Python: 

1. Unzip the ZIP file:

   gunzip python.tar.gz

2. Copy the file to the CAS controller using a command similar to the following:

   kubectl cp python.tar <viya install namespace>/sas-cas-server-default-controller:/tmp -c cas

3. Using Lens, open a shell for the pod where the file was copied;
4. Change folder to /tmp and untar the file:

   cd /tmp && tar -xvf python.tar

5. Untarring the file will generate a folder called "python". Change directory to it, then move each individual sub-folder to the /external-languages/python (this is the one off of the root folder where Python is supposed to be installed):

   cd python 
   mv * /external-languages/python

6. Restart the sas-microanalytic pod, since it cannot run unless Python is present. The same is not true for the CAS controller.
7. For good housekeeping, remember to clean up the /tmp folder inside the pod.
8. Re-zip the original tar file:

   gzip python.tar
