This directory contains two scripts that are needed to deploy Viya
manually:

- Kustomize: Generates the site.yaml file;
- Deploy: Deploys the site.yaml file previously created

However, it's strongly recommended that Viya be deployed using the 
SAS Deployment Operator, whose files are located in the Operator
folder parallel to this one.
