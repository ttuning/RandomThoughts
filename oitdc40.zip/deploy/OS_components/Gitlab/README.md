Create the resources needed to run Gitlab on Kubernetes as follows:

- Create Gitlab's namespace:
  Run Gitlab-ns.yaml (kubectl create -f Gitlab-ns.yaml)
- Create the LDAP secret:
  Run Gitlab-ldap-secret.yaml (kubectl create -f Gitlab-ldap-secret.yaml)
- Deploy Gitlab:

  helm repo add gitlab https://charts.gitlab.io/
  helm repo update

  helm upgrade \
       --install gitlab gitlab/gitlab \
       --namespace gitlab \
       --create-namespace \
       --values values.yaml \
       --timeout 600s

  Note: the upgrade command can and should be used to apply changes
  made to the values.yaml file.
- For the initial login as root, retrieve the password using the following
  command:

  kubectl -n gitlab get secret gitlab-gitlab-initial-root-password -ojsonpath='{.data.password}' | base64 --decode ; echo

Log on to Gitlab using a URL similar to the following one:

http://gitlab.demo.sas.com:8088

Since Gitlab is integrated with Viya's Openldap, credentials for
existing LDAP users can be used to log on.
