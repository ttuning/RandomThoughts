This folder contains instructions on how to install the main OS
components needed by Viya 4. You don't need to run any of these
commands unless you are performing a full install/re-install.
