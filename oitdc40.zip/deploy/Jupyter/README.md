This RACE collection provides two different versions of Jupyter,
JupyterHub (default), and JupyterLab. The former allows for users
to be authenticated using the same LDAP server as for Viya, but 
lacks the ability to mount NFS folders. The latter can mount such
folders but lacks authentication capabilities.

Choose whatever flavor suits you the best!
