#!/bin/sh
source /root/.bashrc

#==============================================================#
# Install certificates for Jupyter                             #
#==============================================================#
jupyter_lab_pod=`kubectl get pods -n jupyter-lab | grep -vE 'service|NAME' | awk '{print $1}'`
cas_controller_pod=`kubectl get pods -n sas-viya | grep controller | awk '{print $1}'`

if [ ! -z $jupyter_lab_pod ] && [ ! -z $cas_controller_pod ]
   then
      echo -ne `date` "Verifying semaphore...\n"
      check_cert="$(kubectl exec -it $jupyter_lab_pod -n jupyter-lab -- /bin/sh -c 'ls -al /tmp/jupyter-ssl.sem' | awk -v RS='\r\n' '{print $9}')"
      if [[ "$check_cert" -eq "directory" ]]
         then
            echo -ne `date` "Downloading the SSL certificates from the CAS controller...\n"
            kubectl cp sas-viya/$cas_controller_pod:/security/trustedcerts.pem -c cas trustedcerts.pem

            echo -ne `date` "Uploading the SSL certificates onto JupyterLab...\n"
            jupyter_lab_pod=`kubectl get pods -n jupyter-lab | grep -vE 'service|NAME' | awk '{print $1}'`
            kubectl cp trustedcerts.pem jupyter-lab/$jupyter_lab_pod:/opt/notebooks/

            echo -ne `date` "Adding the SSL certificates to the trust store...\n"
            kubectl exec -it $jupyter_lab_pod -n jupyter-lab -- /bin/sh -c "cd /opt/conda/ssl && mv /opt/notebooks/trustedcerts.pem cacert.pem.new && cat cacert.pem >> cacert.pem.new && mv cacert.pem cacert.pem.orig && mv cacert.pem.new cacert.pem"

            echo -ne `date` "Cleaning up...\n"
            rm -rf trustedcerts.pem

            echo -ne `date` "Create semaphore...\n"
            kubectl exec -it $jupyter_lab_pod -n jupyter-lab -- /bin/sh -c "touch /tmp/jupyter-ssl.sem"

            echo -ne `date` "Done!\n"
         else
            echo -ne `date` "Semaphore found.\n"
         fi
      else
         echo -ne `date` "JupyterLab is not running.\n"
      fi

exit 0
