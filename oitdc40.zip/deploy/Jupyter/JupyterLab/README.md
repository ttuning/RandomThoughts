Create the resources needed to run JupyterLab on Kubernetes as follows:

- Create Jupyter's namespace:
  Run jupyterlab-ns.yaml (kubectl create -f jupyterlab-ns.yaml)
- Create the Jupyter deployment
  Run jupyterlab-deploy.yaml (kubectl create -f jupyterlab-deploy.yaml)
- Associate a service to Jupyter
  Run jupyterlab-svc.yaml (kubectl create -f jupyterlab-svc.yaml)
- Optionally, install the SSL certificates needed to connect to a secure Viya
  ./jupyterlab-ssl.sh
  To install the SSL certificates in an automated way, add the following entry
  to a crontab:

  */30 * * * * /root/project/deploy/JupyterLab/jupyterlab-ssl.sh > /tmp/jupyterlab-ssl.out

Log on to JupyterLab using a URL similar to the following one:

http://server.demo.sas.com:8888/lab

NOTE:

The JupyterLab image is a customization of the original
(continuumio/anaconda3). The changes applied to the image include:

- The installation of the libnuma-dev libraries
- The installation of the saspy and swat Python packages
- The installation of the SSL certificates needed to connect to CAS
- The creation of the "SASUsers" group, with a gid of 2000, the same
  gid used for the group definition in the internal LDAP server.

Once the image has been customized, it needs to be tested then saved:

- Open a browser, then type "http://server.demo.sas.com:8888/lab" to connect to
  JunyperLab.

- Python:
  Open a new Python3 notebook and paste the following code:

  import swat
  conn = swat.CAS('controller.sas-cas-server-default.sas-viya', 5570, protocol='https', username='sasdemo',password='Orion123')
  out = conn.serverstatus()
  out

- R:
  Open a new R notebook and paste the following code:

  library(swat)
  conn_rest <- CAS('controller.sas-cas-server-default.sas-viya', 8777, protocol='https', username='sasdemo', password='Orion123')
  conn_rest
