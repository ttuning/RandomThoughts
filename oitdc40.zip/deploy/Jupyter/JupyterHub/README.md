Create the resources needed to run JupyterLab on Kubernetes as follows:

- Customize the Dockerfile file in this folder. Once done, run the 
  following command to create a Docker image:

  docker build . -t jupyterlab-viya --no-cache

- Tag the newly created image using the following command:

  docker tag jupyterlab-viya localhost:5000/jupyterlab-viya

- Push the image to the local registry using the following command:

  docker push localhost:5000/jupyterlab-viya

  NOTE: the image can be pushed to a different registry if needed. Make 
  sure to tag it appropriately before pushing it. For a local registry,
  if it doesn't exist it can be created using a command similar to the
  following:

  docker run -d -p 5000:5000 --restart=always --name registry registry:2

- Run (or re-run in case JupyterHub is already up) the following command
  found inside the JupyterHub file in this folder to install JupyterHub:

  helm upgrade --cleanup-on-fail
               --install jupyterhub jupyterhub/jupyterhub   
               --namespace jupyterhub   
               --create-namespace   
               --version=1.2.0 # optional
               --values config.yaml

  NOTE: The above command needs to be run every time the config.yaml file
  changes. If JupyterHub is running, the command restarts it.

- Log on to JupyterLab using a URL similar to the following one:

  http://server.demo.sas.com:8080/hub

  Use one between sasdemo and sasdemo0[1-3] ids to connect.

NOTE:

Once JupyterHub is installed, CAS connectivity can be tested as follows:

- Python:
  Open a new Python3 notebook and paste the following code:

  import swat
  conn = swat.CAS('https://server.demo.sas.com:443/cas-shared-default-http/', username='sasdemo',password='Orion123')
  out = conn.serverstatus()
  out

- R:
  Open a new R notebook and paste the following code:

  library(swat)
  conn_rest <- CAS('controller.sas-cas-server-default.sas-viya', 8777, protocol='https', username='sasdemo', password='Orion123')
  conn_rest
