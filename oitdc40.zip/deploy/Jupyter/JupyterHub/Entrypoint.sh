#!/usr/bin/env bash
# ------------------------------------------------------------------------------ #
# Establishes entry point for Jupyter singleuser image                           #
# ------------------------------------------------------------------------------ #
mkdir -p /home/jovyan/${JUPYTERHUB_USER}

# ------------------------------------------------------------------------------ #
# Create sample notebook to test CAS connectivity with Python                    #
# ------------------------------------------------------------------------------ #
cat << EOF > /home/jovyan/${JUPYTERHUB_USER}/CAS_Python_Connectivity.ipynb
{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "5d0cb24b-9bd9-4bb0-88ab-242171f4ec38",
   "metadata": {},
   "outputs": [],
   "source": [
    "# Do not modify this file!\n",
    "import swat\n",
    "conn = swat.CAS('https://server.demo.sas.com:443/cas-shared-default-http/', username='${JUPYTERHUB_USER}',password='Orion123')\n",
    "out = conn.serverstatus()\n",
    "out"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.9.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
EOF
chmod 444 /home/jovyan/${JUPYTERHUB_USER}/CAS_Python_Connectivity.ipynb

# ------------------------------------------------------------------------------ #
# Create sample notebook to test CAS connectivity with Python                    #
# ------------------------------------------------------------------------------ #
cat << EOF > /home/jovyan/${JUPYTERHUB_USER}/CAS_R_Connectivity.ipynb
{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "39ed619b-5e3b-4ca3-b9c2-40820a4f18c5",
   "metadata": {},
   "outputs": [],
   "source": [
    "# Do not modify this file!\n",
    "library(swat)\n",
    "conn_rest <- CAS('controller.sas-cas-server-default.sas-viya', 8777, protocol='https', username='${JUPYTERHUB_USER}', password='Orion123')\n",
    "conn_rest"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "R",
   "language": "R",
   "name": "ir"
  },
  "language_info": {
   "codemirror_mode": "r",
   "file_extension": ".r",
   "mimetype": "text/x-r-source",
   "name": "R",
   "pygments_lexer": "r",
   "version": "4.1.3"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
EOF
chmod 444 /home/jovyan/${JUPYTERHUB_USER}/CAS_R_Connectivity.ipynb

# ------------------------------------------------------------------------------ #
# Start Jupyter singleuser...                                                    #
# ------------------------------------------------------------------------------ #
/opt/conda/bin/python3.10 /opt/conda/bin/jupyterhub-singleuser --ip=0.0.0.0 --port=8888 --no-browser --ServerApp.allow_root=True --notebook-dir=/home/jovyan/${JUPYTERHUB_USER}
