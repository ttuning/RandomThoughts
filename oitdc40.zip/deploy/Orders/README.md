Before unpacking a new order, rename the current ../sas-bases folder
to preverse its content in case of problems. Then unpack the order
using a command similar to the following:

tar -xvf SASViyaV4_9CL86J_stable_2021.1.3_20210724.1627086195426_deploymentAssets_2021-07-26T152915.tgz --dir=../sas-viya-deployment

The command will create a "sas-bases" folder one level up from here.
