This folder contains a series of manifests designed to deploy PostgreSQL
14.0 on Kubernetes. The installation requires a valid login for the Docker
registry that contains the PostgreSQL image.

Getting Started

- Using a browser, log on to the Docker registry site with the following
  URL:

  https://hub.docker.com/_/postgres

  Before you can pull the image, you need to sign in with your Docker Hub
  account to accept the license terms. If you don't have an account, open
  one as part of the logon process.

- Once you have signed in, create the namespace where PostgreSQL will be 
  installed using the following command:

  kubectl create -f PostgreSQL-namespace.yaml

- A couple of options are available to create a secret to pull the image 
  from the Docker Hub registry. The first one uses the command below.
  Make sure to replace "user" and "pwd" with the Docker Hub account user
  and password from the previous step:

  kubectl create secret docker-registry postgres-image-pull-secret -n postgres --docker-server="https://index.docker.io/v1/" --docker -username="<user>" --docker-password="<pwd>"

  The second option requires that you log on to the Docker Hub registry
  first:

  docker login https://index.docker.io/v1/

  When prompted, enter your Docker Hub credentials then press Enter. This 
  steps creates or updates the ~/.docker/config.json file which stores
  credentials to access Docker registries. The secret can then be created
  using the following command:

  kubectl create secret generic postgres-image-pull-secret -n postgres --from-file=.dockerconfigjson=$HOME/.docker/config.json --type=kubernetes.io/dockerconfigjson

  The second technique is preferrable for the credentials stored in the
  user's config.json file are encrypted, and they wouldn't be shown in 
  clear even after decoding the secret. The same cannot be said for the
  first method.

- Create a secret to store the password for the PostgreSQL database owner
  user using a command similar to the following:

  kubectl create secret generic postgres-postgres-password-secret -n postgres --from-literal=POSTGRES_PASSWORD="<password>"

- Create a configMap to set environment variables for the PostgreSQL
  container:

  kubectl create configmap postgres-database-cm --from-env-file=PostgreSQL.properties -n postgres

- Install PostgreSQL as a stateful set:

  kubectl apply -f PostgreSQL-statefulset.yaml

Testing Connectivity

- To test connectivity from within the container, use the following 
  command:

  kubectl exec -it postgres-0 -n postgres psql -d postgres -U postgres

  When prompted, enter the password for the PostgreSQL database owner
  that was used to create the postgres-postgres-password-secret previously.

- To test connectivity in SAS, a statement similar to the following can be used:

  libname x postgres user=<user> pwd=<password> database=postgres server="postgres-0.postgres.postgres.svc.cluster.local" schema=public;

Optional Customizations

- To create the sample schema, please refer to this link:

  https://www.postgresqltutorial.com/postgresql-sample-database/

  Before running the script, alter the session to point to the correct container:

  alter sesseion set container=orclpdb;

- To create the SASDEMO* sample users, use the following list of statements:

  create role SASDEMO[01|02|03] with password '<password>' login;

- To create the SAMPLE user used by the Postlib pre-defined Caslib, use the following
  statement:

  create role SAMPLE with password 'Orion123' login;
