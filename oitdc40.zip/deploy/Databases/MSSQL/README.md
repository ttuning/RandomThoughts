This folder contains a series of manifests designed to deploy MS SQL Server
2019 on Kubernetes. The installation requires a valid login for the Docker
registry that contains the MS SQL Server image.

Getting Started

- Using a browser, log on to the Docker registry site with the following
  URL:

  https://hub.docker.com/_/microsoft-mssql-server

  Before you can pull the image, you need to sign in with your Docker Hub
  account to accept the license terms. If you don't have an account, open
  one as part of the logon process.

- Once you have signed in, create the namespace where MS SQL Server will be 
  installed using the following command:

  kubectl create -f MSSQL-namespace.yaml

- A couple of options are available to create a secret to pull the image 
  from the Docker Hub registry. The first one uses the command below.
  Make sure to replace "user" and "pwd" with the Docker Hub account user
  and password from the previous step:

  kubectl create secret docker-registry mssql-image-pull-secret -n mssql --docker-server="https://index.docker.io/v1/" --docker -username="<user>" --docker-password="<pwd>"

  The second option requires that you log on to the Docker Hub registry
  first:

  docker login https://index.docker.io/v1/

  When prompted, enter your Docker Hub credentials then press Enter. This 
  steps creates or updates the ~/.docker/config.json file which stores
  credentials to access Docker registries. The secret can then be created
  using the following command:

  kubectl create secret generic mssql-image-pull-secret -n mssql --from-file=.dockerconfigjson=$HOME/.docker/config.json --type=kubernetes.io/dockerconfigjson

  The second technique is preferrable for the credentials stored in the
  user's config.json file are encrypted, and they wouldn't be shown in 
  clear even after decoding the secret. The same cannot be said for the
  first method.

- Create a secret to store the password for the SA user using a command
  similar to the following:

  kubectl create secret generic mssql-sa-password-secret -n mssql --from-literal=SA_PASSWORD="<password>"

- Create a configMap to set environment variables for the MS SQL Server
  container:

  kubectl create configmap mssql-database-cm --from-env-file=MSSQL.properties -n mssql

- Install MS SQL Server as a stateful set:

  kubectl apply -f MSSQL-statefulset.yaml

Testing Connectivity

- To test connectivity from within the container, use the following 
  set of commands:

  kubectl exec -it mssql-0 -n mssql -- /bin/sh
  /opt/mssql-tools/bin/sqlcmd -U sa

  When prompted, enter the password for the SA user that was used to
  create the mssql-sa-password-secret previously.

- To test connectivity in SAS, a statement similar to the following can be used:

  libname x sqlsvr user=<user> pwd=<password> dsn=mssql;

  Where dsn=mssql correspond to the following ODBC entry:

  [MSSQL]
  Driver=/access-clients/odbc/lib/ddsqls27.so
  Description=DataDirect 7.1.6 SQL Server Wire Protocol
  Address=mssql-0.mssql.mssql.svc.cluster.local, 1433
  AlternateServers=
  AnsiNPW=Yes
  ConnectionRetryCount=0
  ConnectionRetryDelay=3
  Database=users
  EnableScrollableCursors=3
  EnableBulkLoad=1
  FetchTSWTZasTimestamp=0
  FetchTWFSasTime=1
  LoadBalancing=0
  LogonID=
  Password=
  QuotedId=Yes
  ReportCodepageConversionErrors=0
  ReportDateTimeType=1
  SnapshotSerializable=0

  For reference, the odbc.ini file is located in /opt/access-clients/odbc.

Optional Customizations

- To create the sample schema, log on to MS SQL Server using the same 
  steps used to test connectivity, then run the following commands:

  create database users;
  go
  create login sample with password = '<password>';
  go
  use users;
  go
  create user sample for login sample;
  go
  grant alter, control to sample;
  go

- To create the SASDEMO* sample users, log on to MS SQL Server using
  the same steps used to test connectivity, then run the following
  commands:

  create login sasdemo|sasdemo01|sasdemo02|sasdemo03 with password = '<password>';
  go
  use users;
  go
  create user sasdemo|sasdemo01|sasdemo02|sasdemo03 for login sasdemo|sasdemo01|sasdemo02|sasdemo03;
  go
  grant alter, control to sasdemo|sasdemo01|sasdemo02|sasdemo03;
  go
