This folder contains the following directories:

- Databases
  Contains folders for the deployment of databases. Currently, they
  include MS SQL Server 2019, PostgreSQL 14.0, and Oracle 19.3.

- Deployment  
  Contains folder for the manual and the deployment-operator based
  deployment of Viya.

- JupyterLab
  Contains the manifests needed to deploy JupyterLab.

- License-and-certificates  
  Contains the license and certificates for Viya.

- OS_components
  Contains a series of folders for the deployment of OS components
  needed to run Viya4 on Kubernetes.

- Orders  
  Contains the Viya order.

- Python  
  Contains the zipped/tarred image of Python should the need arise
  to have to re-install it in Viya.

- R
  Contains the zipped/tarred image or R should the need arise to
  have to re-install it in Viya.

- sas-deployment-operator  
  Contains the manifests needed to deploy the deployment operator.

- sas-viya-deployment  
  Contains the untarred image of the Viya order (sas-bases), along 
  with any customizations applied to the installation (site-config).

- Scripts  
  Contains a variety of scripts to manage the environment.

- SystemServices
  Contains the configuration file for two system services that:
  a) Start Viya at boot time;
  b) Configure ODBC with the IP address of the Windows box where
     some database instances are installed.
